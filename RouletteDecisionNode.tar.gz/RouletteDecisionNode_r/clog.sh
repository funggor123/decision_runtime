#! /bin/bash
rm -r log/*.log
rm -r log/*.log_gin
