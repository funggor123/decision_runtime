#! /bin/bash

# Define
# service_name (depends on service_name in install.sh)
service_name=cd_node

sudo service $service_name stop
