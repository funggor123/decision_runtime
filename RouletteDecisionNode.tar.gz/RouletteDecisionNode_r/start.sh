#! /bin/bash

# Define
# service_name (Depends on service_name in install.sh)
service_name=cd_node

sudo service $service_name start
